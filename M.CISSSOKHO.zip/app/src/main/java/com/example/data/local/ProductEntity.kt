package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val vendorId: Long = 1L,
    val title: String,
    val price: Double,
    val category: String,
    val stockQuantity: Int,
    val description: String,
    val imageDrawableName: String,
    val isAvailable: Boolean = true,
    val salesCount: Int = 0
)
