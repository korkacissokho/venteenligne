package com.example.data.remote

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object GeminiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun getApiKey(): String {
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
    }

    // Models as defined in guidelines
    const val MODEL_FLASH = "gemini-3.5-flash"
    const val MODEL_LITE = "gemini-3.1-flash-lite-preview"
    const val MODEL_PRO = "gemini-3.1-pro-preview"
    const val MODEL_IMAGE = "gemini-3.1-flash-image-preview"

    data class ChatMessage(
        val role: String, // "user" or "model"
        val text: String,
        val isThinking: Boolean = false
    )

    /**
     * Multi-turn chat generation with system instruction & thinking option
     */
    suspend fun generateChatResponse(
        messages: List<ChatMessage>,
        systemInstruction: String = "Vous êtes Vendoo AI, un assistant d'affaires expert en e-commerce et Mobile Money (Wave, Orange Money) pour vendeurs au Sénégal et en Afrique de l'Ouest. Répondez de manière professionnelle, pratique et conviviale en français.",
        model: String = MODEL_FLASH,
        useHighThinking: Boolean = false
    ): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "💡 [Mode Démo AI] Bonjour ! Pour activer la puissance complète de l'IA Gemini en direct, configurez votre GEMINI_API_KEY dans le panneau Secrets de Google AI Studio.\n\nEn attendant, Vendoo AI vous conseille d'optimiser vos titres de produits et de promouvoir vos liens de paiement Wave sur WhatsApp !"
        }

        val targetModel = if (useHighThinking) MODEL_PRO else model
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$targetModel:generateContent?key=$apiKey"

        try {
            val rootObj = JSONObject()

            // System Instruction
            if (systemInstruction.isNotBlank()) {
                val sysObj = JSONObject()
                val partsArr = JSONArray()
                partsArr.put(JSONObject().put("text", systemInstruction))
                sysObj.put("parts", partsArr)
                rootObj.put("systemInstruction", sysObj)
            }

            // Contents array
            val contentsArr = JSONArray()
            messages.forEach { msg ->
                val cObj = JSONObject()
                cObj.put("role", msg.role)
                val pArr = JSONArray()
                pArr.put(JSONObject().put("text", msg.text))
                cObj.put("parts", pArr)
                contentsArr.put(cObj)
            }
            rootObj.put("contents", contentsArr)

            // Generation config
            val genConfig = JSONObject()
            if (useHighThinking) {
                val thinkingObj = JSONObject()
                thinkingObj.put("thinkingLevel", "HIGH")
                genConfig.put("thinkingConfig", thinkingObj)
            }
            rootObj.put("generationConfig", genConfig)

            val body = rootObj.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext "Erreur API Gemini (${response.code}) : $responseStr"
                }

                val jsonResp = JSONObject(responseStr)
                val candidates = jsonResp.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCand = candidates.getJSONObject(0)
                    val contentObj = firstCand.optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "Pas de texte généré.")
                    }
                }
                "Réponse Gemini vide."
            }
        } catch (e: Exception) {
            "Erreur de connexion Gemini AI : ${e.localizedMessage}"
        }
    }

    /**
     * Image Analysis (Multimodal photo inspection for auto-filling product info)
     */
    suspend fun analyzeProductImage(
        bitmap: Bitmap,
        prompt: String = "Analyse cette photo de produit pour un vendeur e-commerce au Sénégal. Donne un JSON valide avec les clés: 'title' (titre vendeur court), 'category' (Mode, Tech, Beauté, ou Accessoires), 'description' (description attrayante en français), et 'estimatedPriceXof' (prix estimé en FCFA sous forme d'entier, ex: 15000)."
    ): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext """
                {
                  "title": "Produit Scanné AI",
                  "category": "Mode",
                  "description": "Article de haute qualité prêt à la vente sur Vendoo avec paiement Wave & Orange Money.",
                  "estimatedPriceXof": 12500
                }
            """.trimIndent()
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_PRO:generateContent?key=$apiKey"

        try {
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
            val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

            val rootObj = JSONObject()
            val contentsArr = JSONArray()
            val contentObj = JSONObject()
            contentObj.put("role", "user")

            val partsArr = JSONArray()
            partsArr.put(JSONObject().put("text", prompt))

            val inlineDataObj = JSONObject()
            inlineDataObj.put("mimeType", "image/jpeg")
            inlineDataObj.put("data", base64Image)
            partsArr.put(JSONObject().put("inlineData", inlineDataObj))

            contentObj.put("parts", partsArr)
            contentsArr.put(contentObj)
            rootObj.put("contents", contentsArr)

            val body = rootObj.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext "Erreur d'analyse photo Gemini (${response.code})"
                }

                val jsonResp = JSONObject(responseStr)
                val candidates = jsonResp.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCand = candidates.getJSONObject(0)
                    val content = firstCand.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "")
                    }
                }
                "Réponse Gemini vide."
            }
        } catch (e: Exception) {
            "Erreur d'analyse photo : ${e.localizedMessage}"
        }
    }
}
