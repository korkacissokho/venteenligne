package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val orderCode: String,
    val vendorId: Long = 1L,
    val customerPhone: String,
    val customerName: String = "Client Express",
    val deliveryAddress: String,
    val totalAmount: Double,
    val paymentMethod: String, // "WAVE", "ORANGE_MONEY", "MTN_MONEY"
    val paymentStatus: String, // "PAYE", "EN_ATTENTE", "ECHOUE"
    val orderStatus: String,   // "EN_ATTENTE", "EN_COURS", "LIVRE", "ANNULE"
    val transactionRef: String,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
