package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vendors")
data class VendorEntity(
    @PrimaryKey val id: Long = 1L,
    val storeName: String,
    val tagline: String,
    val category: String,
    val phone: String,
    val email: String,
    val currency: String = "FCFA",
    val waveNumber: String,
    val orangeMoneyNumber: String,
    val mtnMoneyNumber: String,
    val bio: String,
    val bannerResName: String = "img_vendor_banner",
    val isVerified: Boolean = true,
    val maxProductLimit: Int = 20,
    val isSubscribed: Boolean = false,
    val subscriptionTierName: String = "Gratuit (20 produits)",
    val subscriptionPhone: String = ""
)
