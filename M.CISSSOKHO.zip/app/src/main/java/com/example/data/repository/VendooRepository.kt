package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.ProductEntity
import com.example.data.local.VendorEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class VendooRepository(private val db: AppDatabase) {
    val vendor: Flow<VendorEntity?> = db.vendorDao().getVendorById(1L)
    val products: Flow<List<ProductEntity>> = db.productDao().getProductsByVendor(1L)
    val orders: Flow<List<OrderEntity>> = db.orderDao().getOrdersByVendor(1L)

    fun getOrderItems(orderId: Long): Flow<List<OrderItemEntity>> {
        return db.orderDao().getOrderItems(orderId)
    }

    suspend fun getOrderItemsSync(orderId: Long): List<OrderItemEntity> {
        return db.orderDao().getOrderItemsSync(orderId)
    }

    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        val existingVendor = db.vendorDao().getVendorSync(1L)
        if (existingVendor == null) {
            val vendor = VendorEntity(
                id = 1L,
                storeName = "Dakar Elite Boutique",
                tagline = "Mode, High-Tech & Beauté Authentique",
                category = "Boutique Multi-marques",
                phone = "+221 77 450 89 20",
                email = "contact@dakarelite.sn",
                currency = "FCFA",
                waveNumber = "+221 77 450 89 20",
                orangeMoneyNumber = "+221 77 123 45 67",
                mtnMoneyNumber = "+225 07 88 99 00",
                bio = "Vendeur vérifié sur Vendoo. Expédition rapide à Dakar, Abidjan et sous-région. Paiements 100% sécurisés via Mobile Money.",
                bannerResName = "img_vendor_banner",
                isVerified = true
            )
            db.vendorDao().insertVendor(vendor)

            // Seed Products
            val p1Id = db.productDao().insertProduct(
                ProductEntity(
                    title = "Sac Luxury Pattern Wax",
                    price = 25000.0,
                    category = "Mode",
                    stockQuantity = 14,
                    description = "Sac à main fait main en cuir véritable d'Afrique de l'Ouest avec finition élégante.",
                    imageDrawableName = "img_product_fashion",
                    isAvailable = true,
                    salesCount = 28
                )
            )

            val p2Id = db.productDao().insertProduct(
                ProductEntity(
                    title = "Écouteurs sans Fil SoundPro X",
                    price = 18500.0,
                    category = "Tech",
                    stockQuantity = 22,
                    description = "Écouteurs Bluetooth 5.3 avec réduction de bruit active et autonomie de 24 heures.",
                    imageDrawableName = "img_product_tech",
                    isAvailable = true,
                    salesCount = 42
                )
            )

            val p3Id = db.productDao().insertProduct(
                ProductEntity(
                    title = "Parfum Signature Rose d'Or",
                    price = 32000.0,
                    category = "Beauté",
                    stockQuantity = 8,
                    description = "Fragrance envoûtante aux notes florales et boisées. Flacon de 100ml de haute parfumerie.",
                    imageDrawableName = "img_product_beauty",
                    isAvailable = true,
                    salesCount = 19
                )
            )

            // Seed Orders
            val now = System.currentTimeMillis()
            val day = 86400000L

            val o1Id = db.orderDao().insertOrder(
                OrderEntity(
                    orderCode = "VND-8941",
                    customerPhone = "+221 77 654 32 10",
                    customerName = "Awa Ndiaye",
                    deliveryAddress = "Mermoz Extension, Villa 104, Dakar",
                    totalAmount = 43500.0,
                    paymentMethod = "WAVE",
                    paymentStatus = "PAYE",
                    orderStatus = "LIVRE",
                    transactionRef = "WV-782019482",
                    timestamp = now - (0.5 * day).toLong(),
                    notes = "Appeler avant la livraison"
                )
            )
            db.orderDao().insertOrderItems(
                listOf(
                    OrderItemEntity(orderId = o1Id, productId = p1Id, productTitle = "Sac Luxury Pattern Wax", quantity = 1, unitPrice = 25000.0),
                    OrderItemEntity(orderId = o1Id, productId = p2Id, productTitle = "Écouteurs sans Fil SoundPro X", quantity = 1, unitPrice = 18500.0)
                )
            )

            val o2Id = db.orderDao().insertOrder(
                OrderEntity(
                    orderCode = "VND-8942",
                    customerPhone = "+221 78 112 33 44",
                    customerName = "Moussa Diop",
                    deliveryAddress = "Sacré-Cœur 3, Immeuble B, Appt 4",
                    totalAmount = 32000.0,
                    paymentMethod = "ORANGE_MONEY",
                    paymentStatus = "PAYE",
                    orderStatus = "EN_COURS",
                    transactionRef = "OM-902184001",
                    timestamp = now - (1.2 * day).toLong()
                )
            )
            db.orderDao().insertOrderItems(
                listOf(
                    OrderItemEntity(orderId = o2Id, productId = p3Id, productTitle = "Parfum Signature Rose d'Or", quantity = 1, unitPrice = 32000.0)
                )
            )

            val o3Id = db.orderDao().insertOrder(
                OrderEntity(
                    orderCode = "VND-8943",
                    customerPhone = "+225 07 49 20 11",
                    customerName = "Koffi Mensah",
                    deliveryAddress = "Cocody Angré, Abidjan",
                    totalAmount = 37000.0,
                    paymentMethod = "MTN_MONEY",
                    paymentStatus = "PAYE",
                    orderStatus = "EN_ATTENTE",
                    transactionRef = "MTN-330198522",
                    timestamp = now - (0.1 * day).toLong()
                )
            )
            db.orderDao().insertOrderItems(
                listOf(
                    OrderItemEntity(orderId = o3Id, productId = p2Id, productTitle = "Écouteurs sans Fil SoundPro X", quantity = 2, unitPrice = 18500.0)
                )
            )
        }
    }

    suspend fun updateVendor(vendor: VendorEntity) = withContext(Dispatchers.IO) {
        db.vendorDao().updateVendor(vendor)
    }

    suspend fun addProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        db.productDao().insertProduct(product)
    }

    suspend fun updateProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        db.productDao().updateProduct(product)
    }

    suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        db.productDao().deleteProduct(product)
    }

    suspend fun createOrder(
        customerPhone: String,
        customerName: String,
        deliveryAddress: String,
        paymentMethod: String,
        transactionRef: String,
        items: List<Pair<ProductEntity, Int>>
    ): String = withContext(Dispatchers.IO) {
        val totalAmount = items.sumOf { it.first.price * it.second }
        val randomCode = "VND-" + (1000..9999).random()

        val order = OrderEntity(
            orderCode = randomCode,
            vendorId = 1L,
            customerPhone = customerPhone,
            customerName = if (customerName.isBlank()) "Client Express" else customerName,
            deliveryAddress = deliveryAddress,
            totalAmount = totalAmount,
            paymentMethod = paymentMethod,
            paymentStatus = "PAYE",
            orderStatus = "EN_ATTENTE",
            transactionRef = transactionRef,
            timestamp = System.currentTimeMillis()
        )

        val orderId = db.orderDao().insertOrder(order)

        val orderItems = items.map { (product, qty) ->
            db.productDao().incrementProductSales(product.id, qty)
            OrderItemEntity(
                orderId = orderId,
                productId = product.id,
                productTitle = product.title,
                quantity = qty,
                unitPrice = product.price
            )
        }
        db.orderDao().insertOrderItems(orderItems)

        randomCode
    }

    suspend fun updateOrderStatus(orderId: Long, status: String) = withContext(Dispatchers.IO) {
        db.orderDao().updateOrderStatus(orderId, status)
    }

    suspend fun updatePaymentStatus(orderId: Long, paymentStatus: String) = withContext(Dispatchers.IO) {
        db.orderDao().updatePaymentStatus(orderId, paymentStatus)
    }
}
