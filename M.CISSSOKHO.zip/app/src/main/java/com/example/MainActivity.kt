package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CustomerCheckoutDialog
import com.example.ui.components.VendorHeaderBar
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.CustomerShopScreen
import com.example.ui.screens.GeminiAiAssistantScreen
import com.example.ui.screens.VendorDashboardScreen
import com.example.ui.screens.VendorOrdersScreen
import com.example.ui.screens.VendorProductsScreen
import com.example.ui.screens.VendorProfileScreen
import com.example.ui.theme.OrangeMoney
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.VendooTheme
import com.example.ui.viewmodel.RoleMode
import com.example.ui.viewmodel.VendooViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: VendooViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            VendooTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

private data class NavTabItem(
    val title: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

@Composable
fun MainAppScreen(viewModel: VendooViewModel) {
    val roleMode by viewModel.roleMode.collectAsStateWithLifecycle()
    val vendorProfile by viewModel.vendorProfile.collectAsStateWithLifecycle()
    val products by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val checkoutResult by viewModel.checkoutResult.collectAsStateWithLifecycle()

    var vendorSelectedTab by remember { mutableIntStateOf(0) }
    var showCheckoutDialog by remember { mutableStateOf(false) }

    val pendingOrdersCount = orders.count { it.orderStatus == "EN_ATTENTE" }

    val navTabs = listOf(
        NavTabItem("Dashboard", Icons.Default.Dashboard),
        NavTabItem("Produits", Icons.Default.Storefront),
        NavTabItem("Commandes", Icons.Default.ShoppingBag, badgeCount = pendingOrdersCount),
        NavTabItem("IA Assistant", Icons.Default.AutoAwesome),
        NavTabItem("Profil SaaS", Icons.Default.Person)
    )

    Scaffold(
        topBar = {
            VendorHeaderBar(
                storeName = vendorProfile?.storeName ?: "Dakar Elite Boutique",
                roleMode = roleMode,
                cartItemCount = cart.values.sum(),
                onToggleRole = {
                    val nextMode = when (roleMode) {
                        RoleMode.VENDOR -> RoleMode.CUSTOMER
                        RoleMode.CUSTOMER -> RoleMode.ADMIN
                        RoleMode.ADMIN -> RoleMode.VENDOR
                    }
                    viewModel.setRoleMode(nextMode)
                },
                onOpenCart = { showCheckoutDialog = true },
                onShareStore = {
                    // Trigger share dialog in dashboard or profile
                    vendorSelectedTab = 0
                }
            )
        },
        bottomBar = {
            if (roleMode == RoleMode.VENDOR) {
                NavigationBar(
                    containerColor = RoyalBluePrimary,
                    contentColor = Color.White
                ) {
                    navTabs.forEachIndexed { index, tab ->
                        val isSelected = vendorSelectedTab == index
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { vendorSelectedTab = index },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (tab.badgeCount > 0) {
                                            Badge(
                                                containerColor = OrangeMoney,
                                                contentColor = Color.White
                                            ) {
                                                Text(tab.badgeCount.toString(), fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = RoyalBluePrimary,
                                selectedTextColor = Color.White,
                                indicatorColor = Color.White,
                                unselectedIconColor = Color.White.copy(alpha = 0.7f),
                                unselectedTextColor = Color.White.copy(alpha = 0.7f)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (roleMode) {
                RoleMode.VENDOR -> {
                    when (vendorSelectedTab) {
                        0 -> VendorDashboardScreen(
                            vendorProfile = vendorProfile,
                            orders = orders,
                            products = allProducts,
                            onNavigateToProducts = { vendorSelectedTab = 1 },
                            onNavigateToOrders = { vendorSelectedTab = 2 }
                        )

                        1 -> VendorProductsScreen(
                            products = products,
                            vendorProfile = vendorProfile,
                            searchQuery = searchQuery,
                            selectedCategory = selectedCategory,
                            onSearchChange = viewModel::setSearchQuery,
                            onCategoryChange = viewModel::setSelectedCategory,
                            onSaveProduct = viewModel::saveProduct,
                            onDeleteProduct = viewModel::deleteProduct,
                            onConfirmSubscription = viewModel::processVendorSubscription
                        )

                        2 -> VendorOrdersScreen(
                            orders = orders,
                            onUpdateOrderStatus = viewModel::updateOrderStatus
                        )

                        3 -> GeminiAiAssistantScreen(
                            onAutoFillProduct = { title, category, desc, price ->
                                viewModel.saveProduct(
                                    id = 0,
                                    title = title,
                                    price = price,
                                    category = category,
                                    stock = 15,
                                    description = desc,
                                    imageName = "img_wax_dress"
                                )
                                vendorSelectedTab = 1
                            }
                        )

                        4 -> VendorProfileScreen(
                            vendorProfile = vendorProfile,
                            onSaveProfile = viewModel::saveVendorProfile
                        )
                    }
                }

                RoleMode.CUSTOMER -> {
                    CustomerShopScreen(
                        vendorProfile = vendorProfile,
                        products = products,
                        cart = cart,
                        searchQuery = searchQuery,
                        selectedCategory = selectedCategory,
                        onSearchChange = viewModel::setSearchQuery,
                        onCategoryChange = viewModel::setSelectedCategory,
                        onAddToCart = viewModel::addToCart,
                        onOpenCheckout = { showCheckoutDialog = true }
                    )
                }

                RoleMode.ADMIN -> {
                    AdminDashboardScreen(
                        vendorProfile = vendorProfile,
                        allProducts = allProducts,
                        orders = orders,
                        onUpdateVendorLimitRemotely = viewModel::updateVendorLimitRemotely
                    )
                }
            }
        }
    }

    if (showCheckoutDialog) {
        val cartItems = cart.mapNotNull { (pId, qty) ->
            val p = allProducts.find { it.id == pId }
            if (p != null) Pair(p, qty) else null
        }

        CustomerCheckoutDialog(
            cartItems = cartItems,
            checkoutResult = checkoutResult,
            onDismiss = {
                showCheckoutDialog = false
                viewModel.resetCheckoutResult()
            },
            onConfirmCheckout = { phone, name, address, wallet ->
                viewModel.processCheckout(
                    customerPhone = phone,
                    customerName = name,
                    deliveryAddress = address,
                    paymentMethod = wallet
                )
            }
        )
    }
}
