package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.ProductEntity
import com.example.data.local.VendorEntity
import com.example.data.repository.VendooRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class RoleMode {
    VENDOR, CUSTOMER, ADMIN
}

enum class PaymentSimStatus {
    IDLE, PROCESSING, SUCCESS, FAILED
}

data class CheckoutResult(
    val status: PaymentSimStatus = PaymentSimStatus.IDLE,
    val orderCode: String = "",
    val transactionRef: String = "",
    val errorMessage: String = ""
)

class VendooViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: VendooRepository

    val roleMode = MutableStateFlow(RoleMode.VENDOR)
    
    val vendorProfile: StateFlow<VendorEntity?>
    val allProducts: StateFlow<List<ProductEntity>>
    val orders: StateFlow<List<OrderEntity>>

    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("Tous")

    // Filtered products flow
    val filteredProducts: StateFlow<List<ProductEntity>>

    // Customer cart state: Map<ProductId, Quantity>
    val cart = MutableStateFlow<Map<Long, Int>>(emptyMap())

    // Payment & checkout simulation state
    val checkoutResult = MutableStateFlow(CheckoutResult())

    init {
        val db = AppDatabase.getDatabase(application)
        repository = VendooRepository(db)

        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }

        vendorProfile = repository.vendor.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

        allProducts = repository.products.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        orders = repository.orders.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredProducts = combine(allProducts, searchQuery, selectedCategory) { products, query, cat ->
            products.filter { p ->
                val matchesQuery = p.title.contains(query, ignoreCase = true) ||
                        p.description.contains(query, ignoreCase = true) ||
                        p.category.contains(query, ignoreCase = true)
                val matchesCat = if (cat == "Tous") true else p.category.equals(cat, ignoreCase = true)
                matchesQuery && matchesCat
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun setRoleMode(mode: RoleMode) {
        roleMode.value = mode
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        selectedCategory.value = category
    }

    // Cart Operations
    fun addToCart(productId: Long) {
        val current = cart.value.toMutableMap()
        val count = current[productId] ?: 0
        current[productId] = count + 1
        cart.value = current
    }

    fun removeFromCart(productId: Long) {
        val current = cart.value.toMutableMap()
        val count = current[productId] ?: 0
        if (count > 1) {
            current[productId] = count - 1
        } else {
            current.remove(productId)
        }
        cart.value = current
    }

    fun clearCart() {
        cart.value = emptyMap()
    }

    // Customer Checkout Simulation
    fun processCheckout(
        customerPhone: String,
        customerName: String,
        deliveryAddress: String,
        paymentMethod: String
    ) {
        if (customerPhone.isBlank()) {
            checkoutResult.value = CheckoutResult(
                status = PaymentSimStatus.FAILED,
                errorMessage = "Veuillez entrer un numéro de téléphone valide."
            )
            return
        }

        val cartMap = cart.value
        if (cartMap.isEmpty()) {
            checkoutResult.value = CheckoutResult(
                status = PaymentSimStatus.FAILED,
                errorMessage = "Votre panier est vide."
            )
            return
        }

        viewModelScope.launch {
            checkoutResult.value = CheckoutResult(status = PaymentSimStatus.PROCESSING)
            
            // Simulate network / Mobile Money USSD push delay
            delay(1800)

            val currentProducts = allProducts.value
            val cartItems = cartMap.mapNotNull { (pId, qty) ->
                val product = currentProducts.find { it.id == pId }
                if (product != null) Pair(product, qty) else null
            }

            val prefix = when (paymentMethod) {
                "WAVE" -> "WV"
                "ORANGE_MONEY" -> "OM"
                else -> "MTN"
            }
            val txRef = "$prefix-" + System.currentTimeMillis().toString().takeLast(8)

            val orderCode = repository.createOrder(
                customerPhone = customerPhone,
                customerName = customerName,
                deliveryAddress = if (deliveryAddress.isBlank()) "Livraison standard" else deliveryAddress,
                paymentMethod = paymentMethod,
                transactionRef = txRef,
                items = cartItems
            )

            clearCart()

            checkoutResult.value = CheckoutResult(
                status = PaymentSimStatus.SUCCESS,
                orderCode = orderCode,
                transactionRef = txRef
            )
        }
    }

    fun resetCheckoutResult() {
        checkoutResult.value = CheckoutResult(status = PaymentSimStatus.IDLE)
    }

    // Vendor Operations
    fun saveProduct(
        id: Long,
        title: String,
        price: Double,
        category: String,
        stock: Int,
        description: String,
        imageName: String
    ) {
        viewModelScope.launch {
            if (id == 0L) {
                repository.addProduct(
                    ProductEntity(
                        title = title,
                        price = price,
                        category = category,
                        stockQuantity = stock,
                        description = description,
                        imageDrawableName = if (imageName.isBlank()) "img_product_fashion" else imageName
                    )
                )
            } else {
                repository.updateProduct(
                    ProductEntity(
                        id = id,
                        title = title,
                        price = price,
                        category = category,
                        stockQuantity = stock,
                        description = description,
                        imageDrawableName = imageName
                    )
                )
            }
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    fun updateOrderStatus(orderId: Long, newStatus: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus)
        }
    }

    fun saveVendorProfile(
        storeName: String,
        tagline: String,
        phone: String,
        email: String,
        waveNum: String,
        orangeNum: String,
        mtnNum: String,
        bio: String
    ) {
        viewModelScope.launch {
            val current = vendorProfile.value ?: VendorEntity(
                id = 1L,
                storeName = storeName,
                tagline = tagline,
                category = "Boutique",
                phone = phone,
                email = email,
                waveNumber = waveNum,
                orangeMoneyNumber = orangeNum,
                mtnMoneyNumber = mtnNum,
                bio = bio
            )
            repository.updateVendor(
                current.copy(
                    storeName = storeName,
                    tagline = tagline,
                    phone = phone,
                    email = email,
                    waveNumber = waveNum,
                    orangeMoneyNumber = orangeNum,
                    mtnMoneyNumber = mtnNum,
                    bio = bio
                )
            )
        }
    }

    fun processVendorSubscription(
        targetLimit: Int,
        phone: String,
        wallet: String,
        price: Int
    ) {
        viewModelScope.launch {
            val current = vendorProfile.value ?: return@launch
            val cleanPhone = phone.replace(" ", "").replace("-", "")
            val isVip = cleanPhone.contains("783980895") && (wallet == "WAVE" || wallet == "ORANGE_MONEY")
            val tierName = if (isVip) "VIP Automatique ($targetLimit prod.)" else "Payé ($targetLimit prod. - $price FCFA)"

            repository.updateVendor(
                current.copy(
                    maxProductLimit = targetLimit,
                    isSubscribed = true,
                    subscriptionTierName = tierName,
                    subscriptionPhone = phone
                )
            )
        }
    }

    fun updateVendorLimitRemotely(newLimit: Int) {
        viewModelScope.launch {
            val current = vendorProfile.value ?: return@launch
            repository.updateVendor(
                current.copy(
                    maxProductLimit = newLimit,
                    isSubscribed = true,
                    subscriptionTierName = "Admin Override ($newLimit prod.)"
                )
            )
        }
    }
}
