package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vendoo SaaS Primary Palette - Sleek Interface Theme
val RoyalBluePrimary = Color(0xFF2563EB) // Electric Blue bg-blue-600
val RoyalBlueLight = Color(0xFF3B82F6) // Light Electric Blue
val RoyalBlueDark = Color(0xFF1D4ED8) // Dark Electric Blue

val WaveCyan = Color(0xFF1DA1F2)
val WaveCyanDark = Color(0xFF0C85D0)

val OrangeMoney = Color(0xFFFF7900)
val OrangeMoneyLight = Color(0xFFFF9433)

val MtnYellow = Color(0xFFFFCB05)
val MtnYellowDark = Color(0xFFD9A800)

// Surface and background colors
val BackgroundLight = Color(0xFFF7F9FC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)

val TextPrimaryDark = Color(0xFF0F172A)
val TextSecondaryDark = Color(0xFF64748B)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
