package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.MtnYellow
import com.example.ui.theme.OrangeMoney
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WaveCyan
import java.text.NumberFormat
import java.util.Locale

fun calculateSubscriptionPrice(targetLimit: Int): Int {
    return when {
        targetLimit <= 20 -> 0
        targetLimit <= 50 -> 500
        targetLimit < 100 -> 1000
        targetLimit == 100 -> 2000
        else -> targetLimit * 10
    }
}

@Composable
fun VendorSubscriptionDialog(
    currentLimit: Int,
    currentProductCount: Int,
    onDismiss: () -> Unit,
    onConfirmSubscription: (targetLimit: Int, phone: String, wallet: String, price: Int) -> Unit
) {
    var targetLimit by remember { mutableIntStateOf(if (currentLimit <= 20) 50 else 100) }
    var customLimitStr by remember { mutableStateOf("150") }
    var isCustomSelected by remember { mutableStateOf(false) }

    var phone by remember { mutableStateOf("+221 78 398 08 95") }
    var selectedWallet by remember { mutableStateOf("WAVE") } // "WAVE", "ORANGE_MONEY", "MTN_MONEY"

    var isProcessing by remember { mutableStateOf(false) }
    var isSuccess by remember { mutableStateOf(false) }
    var autoValidatedNotice by remember { mutableStateOf("") }

    val effectiveLimit = if (isCustomSelected) (customLimitStr.toIntOrNull() ?: 50) else targetLimit
    val priceFCFA = calculateSubscriptionPrice(effectiveLimit)
    val formattedPrice = NumberFormat.getNumberInstance(Locale.FRANCE).format(priceFCFA.toLong())

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = OrangeMoney,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Abonnement Vendeur Pro",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Fermer")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Augmentez le nombre de produits visibles sur votre boutique Vendoo.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                if (isProcessing) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            color = if (selectedWallet == "WAVE") WaveCyan else OrangeMoney,
                            modifier = Modifier.size(52.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Vérification du paiement en cours...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Vérification automatique pour $phone via $selectedWallet",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                } else if (isSuccess) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(SuccessGreen.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = SuccessGreen,
                                modifier = Modifier.size(44.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Abonnement Activé !",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = SuccessGreen
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = autoValidatedNotice,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            color = RoyalBluePrimary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                onConfirmSubscription(effectiveLimit, phone, selectedWallet, priceFCFA)
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                        ) {
                            Text("Continuer mes Ventes", fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    // Plan Selection
                    Text(text = "Choisissez votre capacité de produits :", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SubscriptionPlanOption(
                            title = "Jusqu'à 20 Produits",
                            priceText = "GRATUIT (0 FCFA)",
                            selected = !isCustomSelected && targetLimit == 20,
                            badgeText = "Par défaut",
                            onSelect = {
                                isCustomSelected = false
                                targetLimit = 20
                            }
                        )

                        SubscriptionPlanOption(
                            title = "Jusqu'à 50 Produits",
                            priceText = "500 FCFA",
                            selected = !isCustomSelected && targetLimit == 50,
                            badgeText = "Populaire",
                            onSelect = {
                                isCustomSelected = false
                                targetLimit = 50
                            }
                        )

                        SubscriptionPlanOption(
                            title = "Jusqu'à 100 Produits",
                            priceText = "2 000 FCFA",
                            selected = !isCustomSelected && targetLimit == 100,
                            badgeText = "Recommandé",
                            onSelect = {
                                isCustomSelected = false
                                targetLimit = 100
                            }
                        )

                        // Custom Tier Option
                        SubscriptionPlanOption(
                            title = "Plus de 100 Produits",
                            priceText = "10 FCFA / produit supplémentaire",
                            selected = isCustomSelected,
                            badgeText = "Sur-Mesure",
                            onSelect = {
                                isCustomSelected = true
                            }
                        )
                    }

                    if (isCustomSelected) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customLimitStr,
                            onValueChange = { customLimitStr = it },
                            label = { Text("Nombre de produits souhaité (ex: 150)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant)
                    Spacer(modifier = Modifier.height(14.dp))

                    // Special Notice Banner for Auto Validation Phone Number
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(WaveCyan.copy(alpha = 0.12f))
                            .border(1.dp, WaveCyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = WaveCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Validation Automatique : Utilisez le numéro +221 78 398 08 95 par Wave ou Orange Money pour une activation instantanée sans attente !",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = RoyalBluePrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Numéro de paiement Mobile Money") },
                        leadingIcon = { Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = RoyalBluePrimary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "Moyen de Paiement :", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WalletChip(
                            label = "Wave",
                            selected = selectedWallet == "WAVE",
                            color = WaveCyan,
                            onSelect = { selectedWallet = "WAVE" },
                            modifier = Modifier.weight(1f)
                        )
                        WalletChip(
                            label = "Orange Money",
                            selected = selectedWallet == "ORANGE_MONEY",
                            color = OrangeMoney,
                            onSelect = { selectedWallet = "ORANGE_MONEY" },
                            modifier = Modifier.weight(1f)
                        )
                        WalletChip(
                            label = "MTN MoMo",
                            selected = selectedWallet == "MTN_MONEY",
                            color = MtnYellow,
                            onSelect = { selectedWallet = "MTN_MONEY" },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = {
                            val cleanPhone = phone.replace(" ", "").replace("-", "")
                            val isVipAutoValid = cleanPhone.contains("783980895") && (selectedWallet == "WAVE" || selectedWallet == "ORANGE_MONEY")

                            isProcessing = true
                            // Simulate fast network call
                            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                isProcessing = false
                                isSuccess = true
                                if (isVipAutoValid) {
                                    autoValidatedNotice = "⚡ ACCÈS VIP AUTOMATIQUE DÉBLOQUÉ pour le numéro +221 78 398 08 95 via $selectedWallet !\nVotre boutique est désormais configurée pour $effectiveLimit produits."
                                } else {
                                    autoValidatedNotice = "Paiement de $formattedPrice FCFA confirmé pour $phone via $selectedWallet.\nVotre quota est mis à jour à $effectiveLimit produits."
                                }
                            }, 1200)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedWallet == "WAVE") WaveCyan else OrangeMoney
                        )
                    ) {
                        Text(
                            text = if (priceFCFA == 0) "Activer la formule Gratuite" else "Payer $formattedPrice FCFA par $selectedWallet",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SubscriptionPlanOption(
    title: String,
    priceText: String,
    selected: Boolean,
    badgeText: String,
    onSelect: () -> Unit
) {
    val borderColor = if (selected) RoyalBluePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    val bgColor = if (selected) RoyalBluePrimary.copy(alpha = 0.08f) else Color.Transparent

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(2.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(
                text = priceText,
                fontSize = 12.sp,
                color = if (selected) RoyalBluePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (badgeText.isNotBlank()) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selected) RoyalBluePrimary else MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = badgeText,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WalletChip(
    label: String,
    selected: Boolean,
    color: Color,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) color.copy(alpha = 0.15f) else Color.Transparent)
            .border(2.dp, if (selected) color else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
            color = if (selected) color else MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
    }
}
