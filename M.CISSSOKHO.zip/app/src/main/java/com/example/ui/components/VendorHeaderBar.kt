package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.OrangeMoney
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.viewmodel.RoleMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VendorHeaderBar(
    storeName: String,
    roleMode: RoleMode,
    cartItemCount: Int,
    onToggleRole: () -> Unit,
    onOpenCart: () -> Unit,
    onShareStore: () -> Unit
) {
    Surface(
        color = RoyalBluePrimary,
        shadowElevation = 4.dp
    ) {
        TopAppBar(
            title = {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (storeName.isBlank()) "Vendoo SaaS" else storeName,
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(OrangeMoney, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "PRO",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                    Text(
                        text = when (roleMode) {
                            RoleMode.VENDOR -> "Espace Vendeur"
                            RoleMode.CUSTOMER -> "Aperçu Client"
                            RoleMode.ADMIN -> "Surveillance Admin"
                        },
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp
                    )
                }
            },
            actions = {
                // Toggle Mode Switcher Pill Button (Cycles VENDOR -> CUSTOMER -> ADMIN)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (roleMode == RoleMode.ADMIN) OrangeMoney else Color.White.copy(alpha = 0.2f)
                        )
                        .clickable { onToggleRole() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when (roleMode) {
                                RoleMode.VENDOR -> Icons.Default.ShoppingBag
                                RoleMode.CUSTOMER -> Icons.Default.Storefront
                                RoleMode.ADMIN -> Icons.Default.Storefront
                            },
                            contentDescription = "Changer Mode",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = when (roleMode) {
                                RoleMode.VENDOR -> "Passer Client"
                                RoleMode.CUSTOMER -> "Passer Admin"
                                RoleMode.ADMIN -> "Passer Vendeur"
                            },
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (roleMode == RoleMode.CUSTOMER) {
                    IconButton(onClick = onOpenCart) {
                        BadgedBox(
                            badge = {
                                if (cartItemCount > 0) {
                                    Badge(
                                        containerColor = OrangeMoney,
                                        contentColor = Color.White
                                    ) {
                                        Text(text = cartItemCount.toString(), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = "Panier",
                                tint = Color.White
                            )
                        }
                    }
                } else {
                    IconButton(onClick = onShareStore) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Partager Boutique",
                            tint = Color.White
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = RoyalBluePrimary
            )
        )
    }
}
