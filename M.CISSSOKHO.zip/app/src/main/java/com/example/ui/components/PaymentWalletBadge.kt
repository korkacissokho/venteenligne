package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MtnYellow
import com.example.ui.theme.OrangeMoney
import com.example.ui.theme.WaveCyan

@Composable
fun PaymentWalletBadge(
    method: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label, icon) = when (method.uppercase()) {
        "WAVE" -> Quadruple(
            WaveCyan.copy(alpha = 0.15f),
            WaveCyan,
            "Wave",
            Icons.Default.WaterDrop
        )
        "ORANGE_MONEY", "ORANGE" -> Quadruple(
            OrangeMoney.copy(alpha = 0.15f),
            OrangeMoney,
            "Orange Money",
            Icons.Default.PhoneAndroid
        )
        "MTN_MONEY", "MTN" -> Quadruple(
            MtnYellow.copy(alpha = 0.25f),
            Color(0xFF856400),
            "MTN MoMo",
            Icons.Default.AccountBalanceWallet
        )
        else -> Quadruple(
            Color.Gray.copy(alpha = 0.15f),
            Color.DarkGray,
            method,
            Icons.Default.AccountBalanceWallet
        )
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = textColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = textColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
