package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.ProductEntity
import com.example.data.local.VendorEntity
import com.example.ui.components.ProductItemCard
import com.example.ui.components.VendorSubscriptionDialog
import com.example.ui.theme.OrangeMoney
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SuccessGreen

@Composable
fun VendorProductsScreen(
    products: List<ProductEntity>,
    vendorProfile: VendorEntity?,
    searchQuery: String,
    selectedCategory: String,
    onSearchChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onSaveProduct: (id: Long, title: String, price: Double, category: String, stock: Int, desc: String, img: String) -> Unit,
    onDeleteProduct: (ProductEntity) -> Unit,
    onConfirmSubscription: (targetLimit: Int, phone: String, wallet: String, price: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var showProductDialog by remember { mutableStateOf(false) }
    var showSubscriptionDialog by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }

    val maxLimit = vendorProfile?.maxProductLimit ?: 20
    val currentCount = products.size
    val isLimitReached = currentCount >= maxLimit

    val categories = listOf("Tous", "Mode", "Tech", "Beauté", "Accessoires")

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (isLimitReached) {
                        showSubscriptionDialog = true
                    } else {
                        editingProduct = null
                        showProductDialog = true
                    }
                },
                containerColor = if (isLimitReached) OrangeMoney else RoyalBluePrimary,
                contentColor = Color.White
            ) {
                Icon(
                    imageVector = if (isLimitReached) Icons.Default.Lock else Icons.Default.Add,
                    contentDescription = if (isLimitReached) "Abonnement Requis" else "Ajouter Produit"
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Vendor Quota & Subscription Status Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isLimitReached) OrangeMoney.copy(alpha = 0.12f) else RoyalBluePrimary.copy(alpha = 0.08f))
                    .border(
                        1.dp,
                        if (isLimitReached) OrangeMoney else RoyalBluePrimary.copy(alpha = 0.3f),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (isLimitReached) OrangeMoney else RoyalBluePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Quota Produits: $currentCount / $maxLimit",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isLimitReached) "Limite atteinte ! Abonnez-vous pour publier plus." else "20 premiers produits gratuits.",
                                fontSize = 11.sp,
                                color = if (isLimitReached) OrangeMoney else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = if (isLimitReached) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }

                    Button(
                        onClick = { showSubscriptionDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isLimitReached) OrangeMoney else RoyalBluePrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isLimitReached) "S'abonner" else "Augmenter",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Rechercher un produit...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Category Chips Row
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    val isSelected = cat.equals(selectedCategory, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { onCategoryChange(cat) },
                        label = { Text(cat, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBluePrimary,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Products Grid
            if (products.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Aucun produit trouvé",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Appuyez sur '+' pour ajouter votre premier produit.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(products, key = { it.id }) { product ->
                        ProductItemCard(
                            product = product,
                            isVendorMode = true,
                            onEditProduct = {
                                editingProduct = product
                                showProductDialog = true
                            },
                            onDeleteProduct = { onDeleteProduct(product) }
                        )
                    }
                }
            }
        }
    }

    if (showProductDialog) {
        AddEditProductDialog(
            product = editingProduct,
            onDismiss = { showProductDialog = false },
            onSave = { id, title, price, category, stock, desc, img ->
                onSaveProduct(id, title, price, category, stock, desc, img)
                showProductDialog = false
            }
        )
    }

    if (showSubscriptionDialog) {
        VendorSubscriptionDialog(
            currentLimit = maxLimit,
            currentProductCount = currentCount,
            onDismiss = { showSubscriptionDialog = false },
            onConfirmSubscription = { targetLimit, phone, wallet, price ->
                onConfirmSubscription(targetLimit, phone, wallet, price)
                showSubscriptionDialog = false
            }
        )
    }
}

@Composable
private fun AddEditProductDialog(
    product: ProductEntity?,
    onDismiss: () -> Unit,
    onSave: (id: Long, title: String, price: Double, category: String, stock: Int, desc: String, img: String) -> Unit
) {
    var title by remember { mutableStateOf(product?.title ?: "") }
    var priceStr by remember { mutableStateOf(product?.price?.toLong()?.toString() ?: "15000") }
    var category by remember { mutableStateOf(product?.category ?: "Mode") }
    var stockStr by remember { mutableStateOf(product?.stockQuantity?.toString() ?: "10") }
    var description by remember { mutableStateOf(product?.description ?: "") }
    var selectedImgName by remember { mutableStateOf(product?.imageDrawableName ?: "img_product_fashion") }

    val imageOptions = listOf(
        Pair("Mode / Bag", "img_product_fashion"),
        Pair("Tech / Audio", "img_product_tech"),
        Pair("Beauté / Parfum", "img_product_beauty")
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (product == null) "Ajouter un Produit" else "Modifier le Produit",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Fermer")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Titre du produit") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text("Prix (FCFA)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = stockStr,
                        onValueChange = { stockStr = it },
                        label = { Text("Stock") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Catégorie (ex: Mode, Tech, Beauté)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "Visuel du produit :", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    imageOptions.forEach { (label, imgName) ->
                        val isSelected = imgName == selectedImgName
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedImgName = imgName },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RoyalBluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val price = priceStr.toDoubleOrNull() ?: 0.0
                        val stock = stockStr.toIntOrNull() ?: 0
                        onSave(product?.id ?: 0L, title, price, category, stock, description, selectedImgName)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
                ) {
                    Text("Enregistrer Produit", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
