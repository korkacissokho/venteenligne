package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.VendorEntity
import com.example.ui.theme.MtnYellow
import com.example.ui.theme.OrangeMoney
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WaveCyan

@Composable
fun VendorProfileScreen(
    vendorProfile: VendorEntity?,
    onSaveProfile: (storeName: String, tagline: String, phone: String, email: String, wave: String, orange: String, mtn: String, bio: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var storeName by remember(vendorProfile) { mutableStateOf(vendorProfile?.storeName ?: "") }
    var tagline by remember(vendorProfile) { mutableStateOf(vendorProfile?.tagline ?: "") }
    var phone by remember(vendorProfile) { mutableStateOf(vendorProfile?.phone ?: "") }
    var email by remember(vendorProfile) { mutableStateOf(vendorProfile?.email ?: "") }
    var waveNum by remember(vendorProfile) { mutableStateOf(vendorProfile?.waveNumber ?: "") }
    var orangeNum by remember(vendorProfile) { mutableStateOf(vendorProfile?.orangeMoneyNumber ?: "") }
    var mtnNum by remember(vendorProfile) { mutableStateOf(vendorProfile?.mtnMoneyNumber ?: "") }
    var bio by remember(vendorProfile) { mutableStateOf(vendorProfile?.bio ?: "") }

    var isSavedMessageVisible by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Paramètres de la Boutique SaaS",
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "Gérez votre profil public et vos comptes Mobile Money de réception.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Store Profile Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Informations Générales",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = RoyalBluePrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text("Nom de la Boutique") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Storefront, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = tagline,
                    onValueChange = { tagline = it },
                    label = { Text("Slogan / Description courte") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Téléphone Principal") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Phone, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email professionnel") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Email, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("Biographie & Présentation Boutique") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mobile Money Accounts Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Comptes de Réception Mobile Money",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = RoyalBluePrimary
                )
                Text(
                    text = "Les clients effectueront leurs virements vers ces numéros.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Wave Number
                OutlinedTextField(
                    value = waveNum,
                    onValueChange = { waveNum = it },
                    label = { Text("Numéro Wave Marchand") },
                    leadingIcon = { Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = WaveCyan) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Orange Money Number
                OutlinedTextField(
                    value = orangeNum,
                    onValueChange = { orangeNum = it },
                    label = { Text("Numéro Orange Money Marchand") },
                    leadingIcon = { Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = OrangeMoney) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // MTN Money Number
                OutlinedTextField(
                    value = mtnNum,
                    onValueChange = { mtnNum = it },
                    label = { Text("Numéro MTN Mobile Money Marchand") },
                    leadingIcon = { Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = MtnYellow) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (isSavedMessageVisible) {
            Text(
                text = "✓ Profil et comptes enregistrés avec succès !",
                color = SuccessGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Button(
            onClick = {
                onSaveProfile(storeName, tagline, phone, email, waveNum, orangeNum, mtnNum, bio)
                isSavedMessageVisible = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary)
        ) {
            Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Enregistrer les Modifications", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
