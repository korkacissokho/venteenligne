package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.OrderEntity
import com.example.data.local.ProductEntity
import com.example.data.local.VendorEntity
import com.example.ui.components.StatCard
import com.example.ui.theme.MtnYellow
import com.example.ui.theme.OrangeMoney
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WaveCyan
import java.text.NumberFormat
import java.util.Locale

@Composable
fun VendorDashboardScreen(
    vendorProfile: VendorEntity?,
    orders: List<OrderEntity>,
    products: List<ProductEntity>,
    onNavigateToProducts: () -> Unit,
    onNavigateToOrders: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showShareQrDialog by remember { mutableStateOf(false) }

    val totalRevenue = orders.filter { it.paymentStatus == "PAYE" }.sumOf { it.totalAmount }
    val totalOrderCount = orders.size
    val deliveredCount = orders.count { it.orderStatus == "LIVRE" }
    val avgOrderValue = if (totalOrderCount > 0) totalRevenue / totalOrderCount else 0.0

    val waveCount = orders.count { it.paymentMethod == "WAVE" }
    val orangeCount = orders.count { it.paymentMethod == "ORANGE_MONEY" }
    val mtnCount = orders.count { it.paymentMethod == "MTN_MONEY" }

    val formatXof = NumberFormat.getNumberInstance(Locale.FRANCE).format(totalRevenue.toLong())
    val formatAvg = NumberFormat.getNumberInstance(Locale.FRANCE).format(avgOrderValue.toLong())

    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Vendor Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalBluePrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    // Translucent circular background decoration
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .align(Alignment.TopEnd)
                            .padding(top = 8.dp, end = 8.dp)
                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                    )

                    Column(modifier = Modifier.padding(22.dp)) {
                        Text(
                            text = "VENTES DU JOUR",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$formatXof FCFA",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = vendorProfile?.storeName ?: "Ma Boutique SaaS",
                            color = Color.White.copy(alpha = 0.95f),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Translucent status pill badges
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "+18% ce mois",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "$totalOrderCount Commandes",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { showShareQrDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = OrangeMoney),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(imageVector = Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Partager Ma Boutique", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = onNavigateToProducts,
                                shape = RoundedCornerShape(14.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f))
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("+ Produit", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Key Metric KPI Cards Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Chiffre d'Affaires",
                    value = "$formatXof FCFA",
                    subtext = "+18% ce mois-ci",
                    icon = Icons.Default.AttachMoney,
                    badgeColor = SuccessGreen,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Commandes",
                    value = "$totalOrderCount reçues",
                    subtext = "$deliveredCount livrées",
                    icon = Icons.Default.ShoppingBag,
                    badgeColor = RoyalBluePrimary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Panier Moyen",
                    value = "$formatAvg FCFA",
                    subtext = "Excellente valeur",
                    icon = Icons.Default.TrendingUp,
                    badgeColor = OrangeMoney,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Taux de Succès",
                    value = "100%",
                    subtext = "Paiements vérifiés",
                    icon = Icons.Default.CheckCircle,
                    badgeColor = WaveCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Mobile Money Payment Breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Répartition des Paiements Mobile Money",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    PaymentDistributionBar(
                        label = "Wave",
                        count = waveCount,
                        total = totalOrderCount,
                        color = WaveCyan
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    PaymentDistributionBar(
                        label = "Orange Money",
                        count = orangeCount,
                        total = totalOrderCount,
                        color = OrangeMoney
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    PaymentDistributionBar(
                        label = "MTN Mobile Money",
                        count = mtnCount,
                        total = totalOrderCount,
                        color = MtnYellow
                    )
                }
            }
        }

        // Quick Orders Overview
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Dernières Commandes",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                OutlinedButton(onClick = onNavigateToOrders) {
                    Text("Tout voir", fontSize = 12.sp)
                }
            }
        }

        val recentOrders = orders.take(3)
        if (recentOrders.isEmpty()) {
            item {
                Text(
                    text = "Aucune commande pour l'instant. Partagez votre lien de boutique pour recevoir vos premières ventes !",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(recentOrders.size) { idx ->
                val order = recentOrders[idx]
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = order.orderCode, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "Client: ${order.customerPhone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${NumberFormat.getNumberInstance(Locale.FRANCE).format(order.totalAmount.toLong())} FCFA",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = SuccessGreen
                            )
                            Text(text = order.paymentMethod, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalBluePrimary)
                        }
                    }
                }
            }
        }
    }

    if (showShareQrDialog) {
        Dialog(onDismissRequest = { showShareQrDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Partager Votre Boutique SaaS",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // QR Code visual placeholder
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .background(Color.White)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(RoyalBluePrimary.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "QR Code Boutique",
                            tint = RoyalBluePrimary,
                            modifier = Modifier.size(120.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Lien unique: vendoo.app/shop/${vendorProfile?.storeName?.lowercase()?.replace(" ", "") ?: "boutique"}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = RoyalBluePrimary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            val shopLink = "https://vendoo.app/shop/${vendorProfile?.storeName?.lowercase()?.replace(" ", "")}"
                            val msg = "Achetez en ligne sur ma boutique ${vendorProfile?.storeName} avec Wave, Orange Money ou MTN Mobile Money: $shopLink"
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, msg)
                            }
                            context.startActivity(Intent.createChooser(intent, "Partager ma boutique"))
                            showShareQrDialog = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Envoyer via WhatsApp / SMS", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { showShareQrDialog = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Fermer")
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentDistributionBar(
    label: String,
    count: Int,
    total: Int,
    color: Color
) {
    val percentage = if (total > 0) (count.toFloat() / total) * 100 else 0f

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(text = "$count transactions (${percentage.toInt()}%)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(if (total > 0) count.toFloat() / total else 0f)
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
        }
    }
}
