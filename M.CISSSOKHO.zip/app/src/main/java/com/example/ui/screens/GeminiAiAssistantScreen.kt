package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.GeminiService
import com.example.ui.theme.OrangeMoney
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WaveCyan
import kotlinx.coroutines.launch

@Composable
fun GeminiAiAssistantScreen(
    onAutoFillProduct: (title: String, category: String, desc: String, price: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var inputText by remember { mutableStateOf("") }
    var isLowLatency by remember { mutableStateOf(false) }
    var isHighThinking by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }

    // Selected Aspect Ratio for Marketing Banners
    var selectedAspectRatio by remember { mutableStateOf("1:1") }
    val aspectRatios = listOf("1:1", "9:16", "16:9", "4:3", "3:4", "2:3", "3:2", "21:9")

    val chatMessages = remember {
        mutableStateListOf(
            GeminiService.ChatMessage(
                role = "model",
                text = "Bonjour ! Je suis Vendoo AI Intelligence ⚡. Je peux vous aider à rédiger des descriptions de produits, créer des campagnes marketing WhatsApp, optimiser vos prix en FCFA ou analyser vos photos de produits !"
            )
        )
    }

    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // AI Controls Bar (Low Latency / High Thinking / Aspect Ratio)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(RoyalBluePrimary.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = RoyalBluePrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Paramètres d'Intelligence AI",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Quick scan photo button
                        Button(
                            onClick = {
                                isGenerating = true
                                scope.launch {
                                    chatMessages.add(
                                        GeminiService.ChatMessage("user", "📷 [Scan Photo Produit AI] Analyse automatique de la photo exemple...")
                                    )
                                    // Simulated scan using sample product
                                    val dummyJson = GeminiService.analyzeProductImage(
                                        BitmapFactory.decodeByteArray(ByteArray(0), 0, 0)
                                    )
                                    isGenerating = false
                                    chatMessages.add(
                                        GeminiService.ChatMessage("model", "✨ Résultat d'analyse photo AI :\n\n$dummyJson\n\nCliquez ci-dessous pour remplir directement le formulaire produit !")
                                    )
                                    onAutoFillProduct(
                                        "Robe Wax Elégante Pro",
                                        "Mode",
                                        "Magnifique robe de création artisanale sénégalaise disponible immédiatement via Wave et Orange Money.",
                                        18500.0
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = WaveCyan),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Scanner Photo", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = MaterialTheme.colorScheme.surfaceVariant)
                Spacer(modifier = Modifier.height(10.dp))

                // Mode Toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Low Latency Toggle
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = if (isLowLatency) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Réponses Rapides (Lite)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Switch(
                            checked = isLowLatency,
                            onCheckedChange = {
                                isLowLatency = it
                                if (it) isHighThinking = false
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = SuccessGreen),
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // High Thinking Mode Toggle
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = if (isHighThinking) OrangeMoney else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Mode Réflexion Haute", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Switch(
                            checked = isHighThinking,
                            onCheckedChange = {
                                isHighThinking = it
                                if (it) isLowLatency = false
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = OrangeMoney),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Aspect Ratio Selector for Marketing Copy & Poster Design
                Text(text = "Format Poster Promo Marketing :", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    aspectRatios.take(4).forEach { ratio ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedAspectRatio == ratio) RoyalBluePrimary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedAspectRatio = ratio }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = ratio,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedAspectRatio == ratio) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chat Message Thread
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chatMessages) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    if (!isUser) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(RoyalBluePrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Box(
                        modifier = Modifier
                            .clip(
                                RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isUser) 16.dp else 4.dp,
                                    bottomEnd = if (isUser) 4.dp else 16.dp
                                )
                            )
                            .background(
                                if (isUser) RoyalBluePrimary else MaterialTheme.colorScheme.surface
                            )
                            .border(
                                width = if (isUser) 0.dp else 1.dp,
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Text(
                            text = msg.text,
                            color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            if (isGenerating) {
                item {
                    Row(
                        modifier = Modifier.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = RoyalBluePrimary,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHighThinking) "Gemini analyse avec raisonnement approfondi..." else "Gemini génère votre réponse...",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input Field and Quick Prompts
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(WaveCyan.copy(alpha = 0.12f))
                    .clickable {
                        inputText = "Rédige une annonce de vente WhatsApp percutante pour mes produits avec paiements Wave & Orange Money au Sénégal !"
                    }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("📱 Pub WhatsApp", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RoyalBluePrimary)
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(OrangeMoney.copy(alpha = 0.12f))
                    .clickable {
                        inputText = "Comment augmenter mes ventes de produits de mode sur Mobile Money ?"
                    }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("📈 Astuces Vente", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = OrangeMoney)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Posez une question à Gemini AI...") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                maxLines = 3
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (inputText.isNotBlank() && !isGenerating) {
                        val userPrompt = inputText
                        inputText = ""
                        chatMessages.add(GeminiService.ChatMessage("user", userPrompt))
                        isGenerating = true

                        scope.launch {
                            val selectedModel = when {
                                isLowLatency -> GeminiService.MODEL_LITE
                                isHighThinking -> GeminiService.MODEL_PRO
                                else -> GeminiService.MODEL_FLASH
                            }

                            val fullPrompt = if (selectedAspectRatio != "1:1") {
                                "$userPrompt\n(Note: Optimise le format pour un visuel de format $selectedAspectRatio)."
                            } else userPrompt

                            val response = GeminiService.generateChatResponse(
                                messages = chatMessages.toList(),
                                model = selectedModel,
                                useHighThinking = isHighThinking
                            )

                            isGenerating = false
                            chatMessages.add(GeminiService.ChatMessage("model", response))
                        }
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(RoyalBluePrimary, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Envoyer",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
